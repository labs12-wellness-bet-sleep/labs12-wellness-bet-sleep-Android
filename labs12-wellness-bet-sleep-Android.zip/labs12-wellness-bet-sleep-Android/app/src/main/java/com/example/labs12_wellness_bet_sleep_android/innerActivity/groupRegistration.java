package com.example.labs12_wellness_bet_sleep_android.innerActivity;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.labs12_wellness_bet_sleep_android.R;

public class groupRegistration extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_group_registration);
    }
}
